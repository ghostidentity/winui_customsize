﻿using Microsoft.UI;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Media;
using WinUIEx;

namespace Custom
{

	public partial class App : Application
	{

		public App()
		{
			this.InitializeComponent();
		}


		protected override void OnLaunched(Microsoft.UI.Xaml.LaunchActivatedEventArgs args)
		{

			#region Transparency
			Current.Resources["WindowCaptionBackground"] = new SolidColorBrush(Colors.Transparent);
			Current.Resources["WindowCaptionBackgroundDisabled"] = new SolidColorBrush(Colors.Transparent);
			#endregion

			MainWindow mw = new MainWindow();
			mw.AppWindow.TitleBar.ExtendsContentIntoTitleBar = true;
			mw.SetIsMinimizable(false);
			mw.SetIsMaximizable(false);
			mw.SetIsResizable(false);
			mw.SystemBackdrop = new MicaBackdrop();
			mw.Height = 400;
			mw.Width = 800;
			mw.Title = "Sample By Mark";
			mw.SetTitleBarBackgroundColors(Colors.Transparent);
			m_window = mw;

			mw.Activate();
		}

		private WindowEx m_window;
	}
}
