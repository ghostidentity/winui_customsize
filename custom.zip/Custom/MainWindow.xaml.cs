using Microsoft.UI.Xaml;
using WinUIEx;

namespace Custom
{

	public sealed partial class MainWindow : WindowEx
	{
		public MainWindow()
		{
			this.InitializeComponent();
		}

		private void myButton_Click(object sender, RoutedEventArgs e)
		{
			myButton.Content = "Clicked";
		}
	}
}
